# Apollo Hospital Analytics Dashboard – Power BI

## Project Overview
This project contains a Power BI report (`.pbix`) for exploring hospital-related data through interactive dashboard pages and visualizations.

## Dashboard Focus
The report is organized into two dashboard pages and includes hospital analytics such as:
- Patient and admission metrics
- Patient demographics
- Medical-condition analysis
- Hospital stay and billing/revenue metrics
- Interactive report filters

## Tools
- Microsoft Power BI
- Power BI Desktop (`.pbix` report file)

## How to View
1. Download `APOLLO_HOSPOTAL_CHARTS.pbix` from this repository.
2. Open it using Microsoft Power BI Desktop.
3. Use the report pages and available filters to explore the dashboard.

## Repository Structure
```text
apollo-hospital-powerbi-dashboard/
├── README.md
└── APOLLO_HOSPOTAL_CHARTS.pbix
```

## Project Note
This repository shares the Power BI report file. Add screenshots and a description of the dataset or data source if you want to make the project easier for recruiters to review without opening Power BI.

## Author
Mohd Zamman Khan
